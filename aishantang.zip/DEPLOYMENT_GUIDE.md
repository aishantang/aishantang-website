# 网站部署指南：如何将网站应用到免费服务器

## 方案一：GitHub Pages（推荐）

GitHub Pages 是 GitHub 提供的免费静态网站托管服务，非常适合托管我们的中医健康管理中心网站。

### 步骤：

1. **创建 GitHub 账号**
   - 访问 [GitHub](https://github.com/) 并注册一个免费账号

2. **创建新仓库**
   - 登录后，点击右上角的 "+" 按钮，选择 "New repository"
   - 仓库名称建议使用 `aishantang` 或 `aishantang-website`
   - 选择 "Public"（公开仓库）
   - 勾选 "Initialize this repository with a README"
   - 点击 "Create repository"

3. **上传网站文件**
   - 进入新创建的仓库
   - 点击 "Upload files" 按钮
   - 拖拽或选择 `index.html` 文件和其他相关文件上传
   - 上传完成后，点击 "Commit changes"

4. **启用 GitHub Pages**
   - 在仓库页面，点击 "Settings" 选项卡
   - 向下滚动找到 "GitHub Pages" 部分
   - 在 "Source" 下拉菜单中选择 "main branch" 或 "master branch"
   - 点击 "Save"
   - 几分钟后，页面会刷新并显示您的网站 URL（通常是 `https://yourusername.github.io/repositoryname/`）

5. **访问您的网站**
   - 打开提供的 URL，您的网站应该已经在线了！

## 方案二：Netlify

Netlify 是另一个流行的免费静态网站托管服务，提供简单的部署流程和额外的功能。

### 步骤：

1. **创建 Netlify 账号**
   - 访问 [Netlify](https://www.netlify.com/) 并使用 GitHub、GitLab 或 Bitbucket 账号注册

2. **部署网站**
   - 登录后，点击 "New site from Git"
   - 选择您的代码仓库提供商（GitHub、GitLab 或 Bitbucket）
   - 授权 Netlify 访问您的仓库
   - 选择您的网站仓库
   - 配置构建选项（对于纯 HTML/CSS/JS 网站，通常不需要特殊配置）
   - 点击 "Deploy site"

3. **访问您的网站**
   - 部署完成后，Netlify 会为您的网站分配一个随机 URL
   - 您可以在项目页面查看和复制这个 URL
   - 您也可以稍后添加自定义域名（如果有）

## 方案三：Vercel

Vercel 是一个专注于前端的云平台，提供简单的静态网站部署。

### 步骤：

1. **创建 Vercel 账号**
   - 访问 [Vercel](https://vercel.com/) 并使用 GitHub、GitLab 或 Bitbucket 账号注册

2. **导入项目**
   - 登录后，点击 "Import Project"
   - 选择 "Import Git Repository"
   - 连接您的代码仓库提供商并选择您的网站仓库
   - 点击 "Import"

3. **部署配置**
   - Vercel 会自动检测项目类型并配置构建设置
   - 对于纯 HTML/CSS/JS 网站，通常不需要额外配置
   - 点击 "Deploy"

4. **访问您的网站**
   - 部署完成后，Vercel 会提供一个预览 URL
   - 您可以立即访问您的网站
   - 您也可以稍后添加自定义域名

## 方案四：Surge

Surge 是一个简单的命令行工具，用于发布静态网站。

### 步骤：

1. **安装 Node.js**
   - 访问 [Node.js 官网](https://nodejs.org/) 下载并安装 Node.js

2. **安装 Surge CLI**
   - 打开命令提示符或终端
   - 运行 `npm install -g surge`

3. **部署网站**
   - 导航到包含您网站文件的目录
   - 运行 `surge`
   - 输入您的邮箱和设置密码（首次使用时）
   - 确认项目路径
   - 为您的网站选择一个 Surge 子域名（或使用默认生成的域名）
   - 部署完成后，Surge 会显示您的网站 URL

## 网站内容更新方法

无论您选择哪种部署方案，更新网站内容的基本流程如下：

1. **修改本地文件**
   - 使用文本编辑器（如 Notepad++、VS Code 等）打开 `index.html` 文件
   - 根据需要修改内容（如服务项目、价格、联系方式等）

2. **重新部署**
   - **GitHub Pages**：将修改后的文件上传到 GitHub 仓库并提交更改
   - **Netlify/Vercel**：将修改后的文件推送到您的 Git 仓库，部署会自动触发
   - **Surge**：在命令行中再次运行 `surge` 命令

## 注意事项

1. **图片链接**
   - 确保所有图片链接都是有效的外部链接（如我们已经设置的那样）
   - 避免使用本地文件路径（如 `./images/picture.jpg`），因为这些在部署后可能无法访问

2. **响应式设计**
   - 我们的网站已经采用响应式设计，可以在不同设备上良好显示
   - 部署后，建议在手机、平板和电脑上测试网站的显示效果

3. **性能优化**
   - 对于免费托管服务，网站加载速度可能会受到一定限制
   - 如需进一步优化，可以考虑压缩图片和代码

4. **自定义域名**
   - 所有这些服务都支持添加自定义域名（通常需要额外费用购买域名）
   - 如果您有自己的域名，可以在各平台的设置中进行配置

5. **定期备份**
   - 建议定期备份您的网站文件，以防数据丢失

如有任何问题或需要进一步的帮助，请参考各平台的官方文档或寻求专业人士的协助。