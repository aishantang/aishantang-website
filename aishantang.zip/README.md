# 六安艾善堂健康管理中心网站使用指南

## 如何手动更改网站内容

### 1. 修改基本信息

**修改联系电话：**
1. 打开 `index.html` 文件
2. 使用搜索功能（Ctrl+F）查找所有 "05643231167"
3. 将其替换为新的电话号码

**修改地址：**
1. 打开 `index.html` 文件
2. 搜索 "六安市XX路XX号"
3. 将其替换为实际地址

**修改邮箱：**
1. 打开 `index.html` 文件
2. 搜索 "info@aishantang.com"
3. 将其替换为实际邮箱地址

### 2. 修改服务项目

1. 打开 `index.html` 文件
2. 找到服务项目部分（搜索 "服务项目"）
3. 每个服务项目都包含以下结构：
```html
<div class="service-card bg-white rounded-lg shadow-lg overflow-hidden">
    <div class="h-48 overflow-hidden">
        <img src="图片链接" alt="服务名称" class="w-full h-full object-cover transition-transform duration-500 hover:scale-110">
    </div>
    <div class="p-6">
        <h3 class="text-xl font-bold mb-4 text-primary-color">服务名称</h3>
        <p class="text-gray-700 mb-4">服务描述...</p>
        <div class="flex justify-between items-center">
            <span class="text-primary-color font-bold">¥价格起</span>
            <a href="#appointment" class="text-accent-color hover:underline flex items-center">
                立即预约 <i class="fas fa-arrow-right ml-2"></i>
            </a>
        </div>
    </div>
</div>
```

4. 修改相应的服务名称、描述、价格和图片链接

### 3. 修改专家团队信息

1. 打开 `index.html` 文件
2. 找到专家团队部分（搜索 "专家团队"）
3. 每个专家信息都包含以下结构：
```html
<div class="expert-card bg-white rounded-lg shadow-lg overflow-hidden">
    <div class="h-64 overflow-hidden">
        <img src="图片链接" alt="专家姓名" class="w-full h-full object-cover">
    </div>
    <div class="p-6 text-center">
        <h3 class="text-xl font-bold mb-2">专家姓名</h3>
        <p class="text-primary-color mb-4">专家职称</p>
        <p class="text-gray-700 mb-4">专家简介...</p>
        <div class="flex justify-center space-x-4">
            <a href="#" class="text-accent-color hover:text-primary-color">
                <i class="fab fa-weixin text-xl"></i>
            </a>
            <a href="#" class="text-accent-color hover:text-primary-color">
                <i class="fas fa-envelope text-xl"></i>
            </a>
        </div>
    </div>
</div>
```

4. 修改相应的专家姓名、职称、简介和图片链接

### 4. 修改首页内容

1. 打开 `index.html` 文件
2. 找到首页英雄区（搜索 "hero-section"）
3. 修改以下内容：
```html
<h1 class="text-4xl md:text-6xl font-bold mb-6 opacity-0" id="hero-title">传承千年中医智慧</h1>
<p class="text-xl md:text-2xl mb-8 opacity-0" id="hero-subtitle">专注健康管理，古法手工艾灸，中医中药调理</p>
```

### 5. 修改关于我们内容

1. 打开 `index.html` 文件
2. 找到关于我们部分（搜索 "关于艾善堂"）
3. 修改相应的描述文本和图片

### 6. 修改图片

1. 准备好新的图片，确保图片格式为常见的网页格式（如JPG、PNG、WebP等）
2. 将图片上传到图片托管服务（如阿里云OSS、腾讯云COS、七牛云等）获取图片URL
3. 在 `index.html` 文件中找到相应的图片链接，替换为新的图片URL

## 网站如何应用

### 方法一：本地使用

1. 在本地计算机上打开 `index.html` 文件即可在浏览器中查看网站
2. 可以通过修改 `index.html` 文件来更新网站内容
3. 适合本地演示或测试使用

### 方法二：部署到服务器

1. **准备服务器**：
   - 购买一个云服务器（如阿里云、腾讯云、华为云等）
   - 选择合适的配置（建议至少1核2G内存）
   - 选择操作系统（建议使用Linux系统，如CentOS或Ubuntu）

2. **安装Web服务器**：
   - 在Linux服务器上安装Nginx或Apache
   - 以Nginx为例：
     ```bash
     # CentOS系统
     yum install nginx -y
     
     # Ubuntu系统
     apt-get update
     apt-get install nginx -y
     ```

3. **上传网站文件**：
   - 使用FTP工具（如FileZilla）或SSH工具（如WinSCP）将网站文件上传到服务器
   - 建议上传到 `/var/www/html/` 目录下

4. **配置Web服务器**：
   - 编辑Nginx配置文件：
     ```bash
     vi /etc/nginx/conf.d/default.conf
     ```
   - 基本配置示例：
     ```
     server {
         listen 80;
         server_name your-domain.com; # 替换为您的域名
         root /var/www/html;
         index index.html;
         
         location / {
             try_files $uri $uri/ =404;
         }
     }
     ```
   - 保存配置并重启Nginx：
     ```bash
     systemctl restart nginx
     ```

5. **配置域名**：
   - 将您的域名解析到服务器的IP地址
   - 在域名注册商的控制面板中添加A记录，将域名指向服务器IP

6. **访问网站**：
   - 等待域名解析生效后，通过浏览器访问您的域名即可查看网站

### 方法三：使用云服务静态网站托管

1. **选择云服务提供商**：
   - 阿里云OSS静态网站托管
   - 腾讯云COS静态网站托管
   - 华为云OBS静态网站托管
   - GitHub Pages（免费）
   - Netlify（免费）

2. **以阿里云OSS为例**：
   - 登录阿里云控制台，创建OSS Bucket
   - 在Bucket属性中开启静态网站托管
   - 设置默认首页为 `index.html`
   - 上传网站文件到OSS Bucket
   - 配置自定义域名（可选）

3. **访问网站**：
   - 通过OSS提供的域名或自定义域名访问网站

## 网站维护建议

1. **定期备份**：定期备份网站文件和数据
2. **内容更新**：定期更新网站内容，保持信息的时效性
3. **安全检查**：定期检查网站的安全性，防止恶意攻击
4. **性能优化**：优化图片大小，减少页面加载时间
5. **响应式测试**：在不同设备上测试网站的显示效果

## 常见问题解决

1. **图片不显示**：
   - 检查图片URL是否正确
   - 确保图片文件存在且可访问
   - 检查图片格式是否被浏览器支持

2. **样式错乱**：
   - 检查CSS文件是否正确加载
   - 清除浏览器缓存后重新加载页面

3. **表单提交不工作**：
   - 检查表单提交的JavaScript代码
   - 确保表单字段的name属性正确设置

4. **移动端显示异常**：
   - 检查响应式设计的CSS代码
   - 使用浏览器的开发者工具测试不同屏幕尺寸下的显示效果

如有其他问题，请联系专业的网站开发人员寻求帮助。